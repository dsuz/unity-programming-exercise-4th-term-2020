﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        Exercise01();
        //Exercise02();
        //Exercise03();
        //Exercise04();
        //Exercise05();

        Console.Write("Hit Enter to exit...");
        Console.ReadLine();
    }

    /// <summary>
    /// 後述の Hamster クラスを修正し、以下を実行した結果が「ハム太郎 は 8 歳です。」になるようにせよ。
    /// ただし、Exercise01 関数（の内容）は修正しないこと。
    /// </summary>
    static void Exercise01()
    {
        Hamster h = new Hamster("ハム太郎", 8);
        h.Show();
    }

    /// <summary>
    /// 後述の Player クラスの GetMP 関数を修正し、残り MP が適切に出力されるようにせよ。
    /// </summary>
    static void Exercise02()
    {
        Player hero = new Player("勇者", 120);
        Player wizard = new Player("魔法使い", 600);
        Player priest = new Player("僧侶", 500);

        Player[] party = { hero, wizard, priest };

        foreach (Player p in party)
        {
            p.Attack();
            Console.WriteLine("残りMP: {0}", p.GetMP());
        }
    }

    /// <summary>
    /// 指定された２行のみを修正し、パーティーの人数が適切に出力されるようにせよ。
    /// </summary>
    static void Exercise03()
    {
        Player hero = new Player("勇者", 120);
        Player wizard = new Player("魔法使い", 600);
        Player priest = new Player("僧侶", 500);

        Player[] party = { hero, wizard, priest };

        // 以下をアンコメントして ??? 部分を適切な語に置き換えよ。
        // Console.WriteLine("パーティーの人数: {0}", Player.???);
    }

    /// <summary>
    /// Exercise04() 内のコメントを参照し、コメントで指示された通りの処理を作れ。
    /// </summary>
    static void Exercise04()
    {
        string s = "The apple NEVER falls far from the tree.";

        // String.ToUpper() メソッドを使って、s を全て大文字にして出力せよ。
        // 参考: https://www.google.com/search?q=string.toupper+C%23
        Console.WriteLine(s.ToLower()); // ヒント

        // String.SubString(int) メソッドを使って、s の先頭から 5 文字目以降を抽出して出力せよ。ただし先頭の文字は 0 文字目としてカウントする。
        // 参考: https://www.google.com/search?q=string.substring+C%23

        // String.IndexOf(string) メソッドを使って、"apple" が登場する場所が何文字目かを出力せよ。ただし先頭の文字は 0 文字目としてカウントする。
        // 参考: https://www.google.com/search?q=string.indexof+C%23
        Console.WriteLine("\"apple\" が登場するのは {0} 文字目です。", 0);   // ヒント
    }

    static void Exercise05()
    {
        PlayGame();
        // 以降の２行の出力結果がそれぞれ「私は God of War を遊んだ」「私は ドラゴンクエスト を遊んだ」になるように PlayGame 関数を書け。
        PlayGame("God of War");        
        PlayGame("ドラゴンクエスト");
        // 以降の２行の出力結果がそれぞれ「私は PS4 で God of War を遊んだ」「私は ファミコン で ドラゴンクエスト を遊んだ」になるように PlayGame 関数を書け。
        PlayGame("God of War", "PS4");
        PlayGame("ドラゴンクエスト", "ファミコン");

        // 以降に PlayGame 関数を使って「私は マリオカート を遊んだ」「私は Switch で マリオカート を遊んだ」「私は Cyberpunk 2077 を遊んだ」「私は PC で Cyberpunk 2077 を遊んだ」と出力せよ。
    }

    static void PlayGame()
    {
        Console.WriteLine("私はゲームを遊んだ");
    }

    static void PlayGame(string gameTitle)
    {

    }

    static void PlayGame(string gameTitle, string platform)
    {

    }
}

/// <summary>
/// Exercise01 の解答は、以下のクラス定義から "//" のコメントをアンコメントし、??? を適切な語に置き変えよ。
/// </summary>
class Hamster
{
    // ??? string name;
    // ??? int age;

    /// <summary>
    /// コンストラクタ
    /// </summary>
    /// <param name="name">名前</param>
    /// <param name="age">年齢</param>
    public Hamster(string name, int age)
    {
        Console.WriteLine("コンストラクターが呼び出された");
        // ???.name = name;
        // ???.age = age;
    }

    public void Show()
    {
        // Console.WriteLine("{0} は {1} 歳です。", ???.name, ???.age);
    }
}

class Player
{
    string job;
    int mp;
    int count;  // Exercise03 を解答するために、Player クラスはこの行 *のみ* を修正せよ。

    public Player(string job, int mp)
    {
        this.job = job;
        this.mp = mp;
        count++;
    }

    /// <summary>
    /// 攻撃する。消費 MP は 5。
    /// </summary>
    public void Attack()
    {
        Console.WriteLine(job + "は敵を攻撃した");
        mp -= 5;
    }

    public int GetMP()
    {
        // Exercise02 を解答するために、Player クラスは *GetMP 関数* のみを修正せよ。
        return 0;
    }
}
