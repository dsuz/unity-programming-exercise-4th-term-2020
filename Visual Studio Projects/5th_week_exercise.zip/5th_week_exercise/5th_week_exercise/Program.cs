﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Exercise43();
        Exercise44();
        Console.Write("Hit Enter to exit...");
        Console.ReadLine();
    }

    /// <summary>
    /// 以下を参考に次を実装せよ。
    /// 1. CellPhone を継承した SmartPhone クラスを定義せよ。
    /// 2. SmartPhone クラスには画面サイズ（縦: height, 横: width）を表すプロパティを定義せよ。
    /// 3. SmartPhone クラスをインスタンス化し、talk メソッドを呼べ。
    /// </summary>
    static void Exercise43()
    {
        Console.WriteLine("=== Exercise43 ===");
        Console.WriteLine("Phone を操作する");
        Phone p = new Phone();
        p.Talk();

        Console.WriteLine("PublicPhone を操作する");
        PublicPhone pp = new PublicPhone();
        pp.Talk();

        Console.WriteLine("CellPhone を操作する");
        CellPhone cp = new CellPhone();
        Console.WriteLine("cp のバッテリー残量は {0} % です。", cp.BatteryPercentage);

        Console.Write("\r\n");
    }

    /// <summary>
    /// 以下を参考に、Player を継承して SuperPlayer クラスを定義し、Player クラスのインスタンスと SuperPlayer クラスのインスタンスを Battle させよ。
    /// ただし、SuperPlayer は相手の体力を攻撃力の２倍だけ減らすことができる。
    /// </summary>
    static void Exercise44()
    {
        Console.WriteLine("=== Exercise44 ===");
        Player p1 = new Player();
        p1.Name = "Player 1";

        Player p2 = new Player();
        p2.Name = "Player 2";

        Battle battle = new Battle(p1, p2);
        battle.Start();

        Console.Write("\r\n");
    }
}

class Phone
{
    public void Talk()
    {
        Console.WriteLine(this.GetType().Name + " で talk");
    }
}

class PublicPhone : Phone
{
    public void Pay()
    {
        Console.WriteLine(this.GetType().Name + " で pay");
    }
}

class CellPhone : Phone
{
    public float BatteryPercentage { get; set; }

    public CellPhone()
    {
        BatteryPercentage = 100.0f;
    }
}

class Player
{
    public string Name { get; set; }

    public int Life
    {
        get
        {
            return m_life;
        }
    }

    int m_life = 0;

    /// <summary>攻撃力</summary>
    public int AttackPower { get; }
    /// <summary>true の時は生存している</summary>
    public bool IsAlive
    {
        get
        {
            if (Life > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public Player()
    {
        this.m_life = 100;
        this.AttackPower = 15;
    }

    /// <summary>
    /// 攻撃する
    /// </summary>
    /// <param name="target">攻撃対象</param>
    public void Attack(Player target)   // 課題を解く時、この関数には virtual キーワードを付けて仮想関数にする。
    {
        int damage = this.AttackPower;
        target.Damage(damage);
        Console.WriteLine("{0} の攻撃: {1} に {2} のダメージを与えた。{1} の残り体力: {3}", this.Name, target.Name, damage, target.Life);
    }

    public void Damage(int damage)
    {
        if (this.m_life > damage)
        {
            this.m_life -= damage;
        }
        else
        {
            this.m_life = 0;
        }
    }
}

class Battle
{
    Player a;
    Player b;

    public Battle(Player a, Player b)
    {
        this.a = a;
        this.b = b;
    }

    /// <summary>
    /// バトルを開始する
    /// </summary>
    public void Start()
    {
        while (true)
        {
            a.Attack(b);

            if (!b.IsAlive)
            {
                ShowResult(a);
                break;
            }

            b.Attack(a);

            if (!a.IsAlive)
            {
                ShowResult(b);
                break;
            }
        }
    }

    /// <summary>
    /// バトルの結果を表示する
    /// </summary>
    /// <param name="winner"></param>
    void ShowResult(Player winner)
    {
        Console.WriteLine("勝者: {0}, 残り体力: {1}", winner.Name, winner.Life);
    }
}
